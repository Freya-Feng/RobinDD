function p=test_pressure(x,y)
p=cos(pi*x).*sin(pi*y);
end