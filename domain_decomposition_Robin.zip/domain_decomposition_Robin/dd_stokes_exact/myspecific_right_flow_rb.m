function [bcx,bcy] = myspecific_right_flow_rb(xbd,ybd)
bcx=zeros(length(xbd),1);bcy=bcx;
return