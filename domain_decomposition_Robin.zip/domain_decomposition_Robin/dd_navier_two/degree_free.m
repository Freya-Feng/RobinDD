%compute degree of freedom
xy=start_data.xy;xyp=start_data.xyp;
nu=length(xy(:,1))
np=length(xyp(:,1))
nu^2+2*nu*np